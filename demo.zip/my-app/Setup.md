

Steps followed to setup this project

- 1. create react app

- 2. install Router, for navigation
react-router-dom
# npm install --save react-router
https://www.npmjs.com/package/react-router

- 3. Install reactstrap and Bootstrap from NPM. Reactstrap does not include Bootstrap CSS so this needs to be installed as well:
# npm install --save bootstrap@4.1.3
# npm install --save jquery
# npm install --save popper
# npm install --save reactstrap react@^16.3.2 react-dom@^16.3.2
Import Bootstrap CSS in the src/index.js file:
> import 'bootstrap/dist/css/bootstrap.css';

https://www.npmjs.com/package/reactstrap

- 4. Install axiom for requests
# npm install --save axiom







    "react": "^15.0.1",
    "react-dom": "^15.0.1",
    "react-router": "^2.0.0",
    "react-router-dom": "^2.0.0",
    // "react": "^16.5.2",
    // "react-dom": "^16.5.2",
    // "react-router": "^4.3.1",
    // "react-router-dom": "^4.3.1",
https://www.npmjs.com/package/react-oauth2