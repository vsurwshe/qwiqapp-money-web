import React, { Component } from "react";
import { Container, Button, Card, CardBody, Col, Row, Alert, CardHeader } from "reactstrap";
import CreateLabel from "./Createlabel";
import ViewLabel from "./ViewLabel";
import LabelApi from "../../services/LabelApi";

class Lables extends Component {
  constructor(props) {
    super(props);
    this.state = {
      labels: [],
      addContainer: false,
      createProfile: false,
      viewLabelRequest: false,
      visible: false,
      id: 0,
      name: "",
      version:"",
      popoverOpen: false,
    };
  }
  //this method get All Labels Realted That Profile
  componentDidMount() {
    new LabelApi().getlabels(this.successCall, this.errorCall,11);
  }
  successCall = json => {
    console.log(json);
    if (json === "Deleted Successfully") {
      this.setState({ labels: [0] })
    }
    else {
      this.setState({ labels: json })
    }
  };

  errorCall = err => { this.setState({ visible: true }) }

  callCreateProfile = () => {
    this.setState({ createProfile: true })
  }

  render() {
   const { labels,viewLabelRequest, createProfile, visible} = this.state
    if (labels.length === 0 && !createProfile) {
      return <div>{this.loadNotLabelProfile()}</div>
    } else if (createProfile) {
      return (<Container> <CreateLabel /> </Container>)
    } else {
      return <div>{this.loadShowLabel(viewLabelRequest, visible, labels)}</div>
    }
  }
  //this method call when if any profile not created.
  loadNotLabelProfile = () => {
    return (<div className="animated fadeIn">
      <Card>
        <CardHeader>
          <strong>Profile</strong>
        </CardHeader>
        <center style={{paddingTop:'20px'}}>
          <CardBody>
            <h5><b>You haven't created any Lables yet... </b></h5><br/>
            <Button color="info" onClick={this.callCreateProfile}> Create Label </Button>
          </CardBody>
        </center>
      </Card>
    </div>)
  }
  //if one or more profile is there then this method Call
  loadShowLabel = (viewLabelRequest, visible, labels) => {
    return (
    <div className="animated fadeIn">
      <Card>
        <CardHeader>
          <strong>Profile</strong>
        </CardHeader>
        <CardBody>
          <h6>
            <Alert isOpen={visible} color="danger">Internal Server Error</Alert>
          </h6>
          <Col sm="6">
            <Row>
              <CardBody>
              <Container >
                {labels.map((labels, key) => {
                    return <ViewLabel key={labels.id} labels={this.state.labels[key]} />
                 })}
                <Button color="info" onClick={this.callCreateProfile}> Create More Label </Button>
                </Container>
              </CardBody>
            </Row>
          </Col>
        </CardBody>
      </Card>
    </div>)
  }
}
export default Lables;