import React, { Component } from "react";
import Profiles from "./Profiles";

class Dashboard extends Component {
  render() {
    return (
      <div>
        <Profiles />
      </div>
    );
  }
}

export default Dashboard;
