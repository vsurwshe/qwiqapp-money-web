
const Config = {
    //  http://localhost:8082/oauth/token
    // authBaseURL: "http://localhost:8081",
    // cloudBaseURL: "http://localhost:8082",
    authBaseURL: "https://124apps.com/bills/auth",
    cloudBaseURL: "https://124apps.com/bills/cloud",
    clientId: "trusted-app",
    clientSecret: "secret"
}

export default Config;